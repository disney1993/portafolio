
function createPaint(parent) {
  var canvas = elt('canvas', { width: 800, height: 500 });
  var cx = canvas.getContext('2d');
  var toolbar = elt('div', { class: 'toolbar' });

  // llama a cada función en controles, pasando en contexto,
  // luego anexando los resultados devueltos a la barra de herramientas
  for (var name in controls)
    toolbar.appendChild(controls[name](cx));

  var panel = elt('div', { class: 'picturepanel' }, canvas);
  parent.appendChild(elt('div', null, panel, toolbar));
}

/************************************************************************
 * helper functions
 ***********************************************************************/

// crea un elemento con un nombre y un objeto (atributos)
// agrega todos los argumentos adicionales que obtiene como nodos secundarios
// los argumentos de cadena crean nodos de texto
// ejemplo: elt('div', {class: 'foo'}, 'Hello, world!');
function elt(name, attributes) {
  var node = document.createElement(name);
  if (attributes) {
    for (var attr in attributes)
      if (attributes.hasOwnProperty(attr))
        node.setAttribute(attr, attributes[attr]);
  }
  for (var i = 2; i < arguments.length; i++) {
    var child = arguments[i];

    // si este argumento es una cadena, crea un nodo de texto
    if (typeof child == 'string')
      child = document.createTextNode(child);
    node.appendChild(child);
  }
  return node;
}

// calcula las coordenadas relativas del lienzo para una funcionalidad precisa
function relativePos(event, element) {
  var rect = element.getBoundingClientRect();
  return {
    x: Math.floor(event.clientX - rect.left),
    y: Math.floor(event.clientY - rect.top)
  };
}

// registra y anula el registro de listeners para herramientas
function trackDrag(onMove, onEnd) {
  function end(event) {
    removeEventListener('mousemove', onMove);
    removeEventListener('mouseup', end);
    if (onEnd)
      onEnd(event);
  }
  addEventListener('mousemove', onMove);
  addEventListener('mouseup', end);
}

// carga una imagen desde una URL y reemplaza el contenido del canvas
function loadImageURL(cx, url) {
  var image = document.createElement('img');
  image.addEventListener('load', function () {
    var color = cx.fillStyle, size = cx.lineWidth;
    cx.canvas.width = image.width;
    cx.canvas.height = image.height;
    cx.drawImage(image, 0, 0);
    cx.fillStyle = color;
    cx.strokeStyle = color;
    cx.lineWidth = size;
  });
  image.src = url;
}

// usado por herramientas.
// posiciona puntos al azar
function randomPointInRadius(radius) {
  for (; ;) {
    var x = Math.random() * 2 - 1;
    var y = Math.random() * 2 - 1;
    // usa el teorema de Pitágoras para probar si un punto está dentro de un círculo
    if (x * x + y * y <= 1)
      return { x: x * radius, y: y * radius };
  }
}

/************************************************** ***********************
  * controles
  *************************************************** *********************/

// contiene métodos estáticos para inicializar los diversos controles;
// Object.create () se usa para crear un objeto verdaderamente vacío
var controls = Object.create(null);

controls.tool = function (cx) {
  var select = elt('select');

  //llenar las herramientas
  for (var name in tools)
    select.appendChild(elt('option', null, name));
  // llama al método particular asociado con la herramienta actual
  cx.canvas.addEventListener('mousedown', function (event) {

    // est'a presionado el botón izquierdo del ratón?
    if (event.which == 1) {

      // el evento necesita ser pasado al método para determinar
      // qué está haciendo el ratón y dónde está
      tools[select.value](event, cx);
      // no seleccionar cuando el usuario está haciendo clic y arrastrando
      event.preventDefault();
    }
  });

  return elt('span', null, 'Tool: ', select);
};

//modulo de selecci'on de color 
controls.color = function (cx) {
  var input = elt('input', { type: 'color' });

  // en el cambio, establecer el nuevo estilo de color para relleno y trazo
  input.addEventListener('change', function () {
    cx.fillStyle = input.value;
    cx.strokeStyle = input.value;
  });
  return elt('span', null, 'Color: ', input);
};

// modulo del tamaño del pincel
controls.brushSize = function (cx) {
  var select = elt('select');

  // varios tamaños de pincel
  var sizes = [1, 2, 3, 5, 8, 12, 25, 35, 50, 75, 100];

  // construir las opciones de tamaños
  sizes.forEach(function (size) {
    select.appendChild(elt('option', { value: size }, size + ' pixels'));
  });

  //actualizar el rozos del pincel
  select.addEventListener('change', function () {
    cx.lineWidth = select.value;
  });
  return elt('span', null, 'Brush size: ', select);
};

// guardar
controls.save = function (cx) {
  // DEBE abrirse en una nueva ventana debido a cosas de seguridad de iframe
  var link = elt('a', { href: '/', target: '_blank' }, 'Save');
  function update() {
    try {
      link.href = cx.canvas.toDataURL();
    } catch (e) {

      if (e instanceof SecurityError)
        link.href = 'javascript:alert(' +
          JSON.stringify('No se puede guardar: ' + e.toString()) + ')';
      else
        window.alert("No.");
      throw e;
    }
  }
  link.addEventListener('mouseover', update);
  link.addEventListener('focus', update);
  return link;
};

// abrir un archivo
controls.openFile = function (cx) {
  var input = elt('input', { type: 'file' });
  input.addEventListener('change', function () {
    if (input.files.length == 0) return;
    var reader = new FileReader();
    reader.addEventListener('load', function () {
      loadImageURL(cx, reader.result);
    });
    reader.readAsDataURL(input.files[0]);
  });
  return elt('div', null, 'Open file: ', input);
};

// abir una url
controls.openURL = function (cx) {
  var input = elt('input', { type: 'text' });
  var form = elt('form', null, 'Open URL: ', input,
    elt('button', { type: 'submit' }, 'load'));
  form.addEventListener('submit', function (event) {
    event.preventDefault();
    loadImageURL(cx, form.querySelector('input').value);
  });
  return form;
};
  //limpiar canvas
  //controls.limpiar=function limpiar(){
   // context.clearRect(0, 0, context.canvas.width, context.canvas.height); // Clears the canvas
  //}

/************************************************************************
 * herramientas
 ***********************************************************************/

// herramientas de dibujo
var tools = Object.create(null);

// herramienta de línea
// onEnd es para la función de borrado
tools.Line = function (event, cx, onEnd) {
  cx.lineCap = 'round';

  // Posición del ratón relativa al canvas.
  var pos = relativePos(event, cx.canvas);
  trackDrag(function (event) {
    cx.beginPath();

    // mover a la posici'on actual del mause
    cx.moveTo(pos.x, pos.y);

    // actualizar posicion del mause
    pos = relativePos(event, cx.canvas);

    //linea a la posiscion actualizada del mause
    cx.lineTo(pos.x, pos.y);

    //trazar la linea
    cx.stroke();
  }, onEnd);
};

// hheramienta borrador
tools.Erase = function (event, cx) {
  // globalCompositeOperation determina cómo las operaciones de dibujo
  // en un lienzo afecta lo que ya está ahí
  // 'destination-out' hace que los píxeles sean transparentes, 'borrándolos'
  // NOTA: esto ha sido descontinuado
  cx.globalCompositeOperation = 'destination-out';
  tools.Line(event, cx, function () {
    cx.globalCompositeOperation = 'source-over';
  });
};

// herramienta de texto
tools.Text = function (event, cx) {
  var text = prompt('Text:', '');
  if (text) {
    var pos = relativePos(event, cx.canvas);
    // simplificando, el tama;o del pincel es el ta;o de la letra,
    // boqueado en la fuente sans-serif
    cx.font = Math.max(7, cx.lineWidth) + 'px sans-serif';
    cx.fillText(text, pos.x, pos.y);
  }
}

// herramienta de spray
tools.Spray = function (event, cx) {
  var radius = cx.lineWidth / 2;
  var area = radius * radius * Math.PI;
  var dotsPerTick = Math.ceil(area / 30);

  var currentPos = relativePos(event, cx.canvas);
  var spray = setInterval(function () {
    for (var i = 0; i < dotsPerTick; i++) {
      var offset = randomPointInRadius(radius);
      cx.fillRect(currentPos.x + offset.x,
        currentPos.y + offset.y, 1, 1);
    }
  }, 25);
  trackDrag(function (event) {
    currentPos = relativePos(event, cx.canvas);
  }, function () {
    clearInterval(spray);
  });
};
// ayudantes para rellenoado

// itera sobre los vecinos N, S, E y W y realiza una función fn
function forEachNeighbor(point, fn) {
  fn({ x: point.x - 1, y: point.y });
  fn({ x: point.x + 1, y: point.y });
  fn({ x: point.x, y: point.y - 1 });
  fn({ x: point.x, y: point.y + 1 });
}

// comprueba si 2 puntos en los datos, punto1 y punto2, tienen el mismo color
function isSameColor(data, point1, point2) {
  var offset1 = (point1.x + point1.y * data.width) * 4;
  var offset2 = (point2.x + point2.y * data.width) * 4;

  for (var i = 0; i < 4; i++) {
    if (data.data[offset1 + i] != data.data[offset2 + i]) {
      return false;
    }
  }
  return true;
}

// termina el rellenado

tools["Flood Fill"] = function (event, cx) {
  var imageData = cx.getImageData(0, 0, cx.canvas.width, cx.canvas.height),
    // obtener el punto de muestra en la posición actual, {x: int, y: int}
    sample = relativePos(event, cx.canvas),
    isPainted = new Array(imageData.width * imageData.height),
    toPaint = [sample];

  // mientras toPaint.length > 0
  while (toPaint.length) {
    // punto actual para verificar
    var current = toPaint.pop(),
      id = current.x + current.y * imageData.width;

    // comprobar si el actual ya ha sido pintada
    if (isPainted[id]) continue;
    else {

      // si no lo ha hecho, pinte el actual y el conjunto se pinta como verdadero
      cx.fillRect(current.x, current.y, 1, 1);
      isPainted[id] = true;
    }

    // para cada vecino
    forEachNeighbor(current, function (neighbor) {
      if (neighbor.x >= 0 && neighbor.x < imageData.width &&
        neighbor.y >= 0 && neighbor.y < imageData.height &&
        isSameColor(imageData, sample, neighbor)) {
        toPaint.push(neighbor);
      }
    });
  }
};

// inicializar la app
var appDiv = document.querySelector('#paint-app');
createPaint(appDiv);